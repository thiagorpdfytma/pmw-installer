-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2456740)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2456741,0,"e91cba2d1d471bdfb115bee76ac997858f84e6ab0a82af5f17d0054f8a3c9686")
setManifestid(2456741,"8321490079515316932")