-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1274570)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(1274571,0,"b56991abb013052ba7ef6d1e0982f0ca99bbeeb631057347267102c6967c1537")
setManifestid(1274571,"6429368298083549179")
addappid(1274572)
addappid(1274573,0,"b67b5c5c44139818a0d7ddb9d1103a724ca404a87bde4d78fe257fc352f0f36d")
setManifestid(1274573,"7439830362653470777")
addappid(1966630,0,"9b579f914a2ba495ad1e0b1e1a1fc21c8e578ee933fb6bfabd9f138124244587")
setManifestid(1966630,"3546735088053658697")