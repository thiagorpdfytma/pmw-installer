-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1244090)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1244091,0,"1549d20da14b7d148867bd5c7ae9353bf17b61ca4b5babd432a332beb9ca8b92")
setManifestid(1244091,"7261303137858943433")
addappid(2550501,0,"8b97c6e0dfb7c12208ed1fd619275b1c92564b93971477f777880be9887198ef")
setManifestid(2550501,"4186430635673826258")