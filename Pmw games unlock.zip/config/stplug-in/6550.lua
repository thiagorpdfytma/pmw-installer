-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(6550)
addappid(6553,0,"07609b801c9cf5e0b633535b972a64d4a9c8760b5a18775c23ff509bdc67e357")
setManifestid(6553,"7101381438732078021")
addappid(6552,0,"2ebef56094868d075732c86d2bddda632e2fdcb766da9064983ceb0c6ff19bce")
setManifestid(6552,"4839038868709177531")
addappid(6551,0,"9fc2e9035811d502e0caefc88bfcdcce0ee92d1cc90bd6f21a4b1795905a50f0")
setManifestid(6551,"6339289565621652548")