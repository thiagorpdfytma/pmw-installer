addappid(2452080)
addappid(2452081,0,"c2d565341531f2032ec2e3340fd71477d019939f2b79db27d6f23898e49e9580")
setManifestid(2452081,"4358565608226294823")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]