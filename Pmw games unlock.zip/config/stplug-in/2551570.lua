addappid(2551570)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2551571,0,"7f8cc23534f4143d80aea505f42bb83dcb942de1b8d0e07b629ce3b9dfa2e6a2")
setManifestid(2551571,"6262027791202689244")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]