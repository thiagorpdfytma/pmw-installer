addappid(488310)
addappid(488311,0,"6a8f5a73fe66474a12587100029fef4b0c2a1344323ae6d0167708fefb00b7b3")
setManifestid(488311,"2452181603971774943")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]