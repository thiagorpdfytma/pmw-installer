addappid(346470)
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(346471,0,"434fbfc437670313405bd744eb11d5907961d2e7f3b7f425177401d584d94587")
setManifestid(346471,"4073073621335903077")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]