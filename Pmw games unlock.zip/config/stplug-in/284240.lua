addappid(284240)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(284241,0,"0822971be91189f317fc07b107eb3bc6de5f0232c240a381b6065127376a145c")
setManifestid(284241,"7221672461901179517")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]