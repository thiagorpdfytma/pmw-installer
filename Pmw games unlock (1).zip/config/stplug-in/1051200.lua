-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1051200)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1051201,0,"32400332d01c6dc6b17b3ea76db10a769992faecba70c077788ced537c79d231")
setManifestid(1051201,"6716871881563049368")
addappid(1051202)