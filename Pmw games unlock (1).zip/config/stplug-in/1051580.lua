-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1051580)
addappid(1051581,0,"264fd0da946f4b7f17a4c99a75afc3d09a842c94c6d0ee77025caf93f07c8f33")
setManifestid(1051581,"4660657030120126527")